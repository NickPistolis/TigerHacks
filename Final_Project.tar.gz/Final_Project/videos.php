<!DOCTYPE html>

<!-- This document was created on 26 April 2017 by Andrew Krall, 16190080-->
<!-- Purpose: CS2830 Final Project -->

<html>
    
    <head>
        
        <!-- Bootstrap Links -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css"><!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css"><!-- Optional theme -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script><!-- Latest compiled and minified JavaScript -->
        
        <title>German Club Website</title> 
        <meta charset="utf-8"> 
        
        <style>
            .testStyle {
                margin: auto;
                font-family: 'Permanent Marker', 'Arial';
                background: white;
                margin-top: 10%;
                margin-bottom: 10%;
                width: 50%;
                height: 50%;
                text-align: center;
                border-radius: 25px;
            }
            
            body {
                background-image: url("Flag_of_Germany.png");
                background-size: 100%;
            }
            
            img {
                width: 300px;
                height: 200px;
            }
        </style>
        
    </head>
    
    <body>
        
        <div class="testStyle">
            <br>
            <?php
set_include_path('templates');
require_once("Template.php");
require_once("MenuComponent.php");

// Set Page Title
$title = 'Home';
// CSS
$css = array();
// HTML
$html = array();


// Build Menu
$menuResult = buildMenu();
$css[] = $menuResult['cssFile'];
$html[] = $menuResult['html'];

// Build Content
$html[] = buildContent();


// Build Page
$page = new Template();

$page->title = $title;
$page->css = $css;
$page->html = $html;

print $page->build('page.tmpl');



function buildMenu() {
	$menuItems = array();
	$menuItems[] = array('label' => 'Home', 'link' => 'index_old.php');
	$menuItems[] = array('label' => 'Login', 'link' => 'login.php');
    $menuItems[] = array('label' => 'Register', 'link' => 'register.php');
    $menuItems[] = array('label' => 'Meeting Dates', 'link' => 'meeting_dates.php');
    $menuItems[] = array('label' => 'Videos', 'link' => 'videos.php');

    //Need to create a variable called $currentPage
    $currentPage = "Videos"; //After adding this line, it will have Home selected as the page.

	$menu = new MenuComponent($menuItems, $currentPage);
	return $menu->generate();
}

function buildContent() {
	$content = new Template();
	$content->myVariable = 'Mr. Wergeles';
	return $content->build('.tmpl');
}
?>
            <?php
                //print "Got here!";
                //index.php?src=XYZ
                //print "Got here!";
              $id = empty($_GET['src']) ? 'ABC' : $_GET['src']; //Ternary operator, will default to 'ABC', otherwise will try to get the video.
                
              $videoData = json_decode(file_get_contents('videoData.json'));
            
              //print_r($videoData);
                //print "Got here!";
              $data = $videoData->$id;

              require_once 'Template.php';
                //print "Got here!";
              $page = new Template();
                if(!$data) {
                    print "$data is null";
                }
              $page->data = $data;

              //Last thing we need to do is print the video to the page.
              print $page->build('videoPage.tmpl');

              //If we add ?&src=XYZ, will show the racoon video instead of the cat video

            ?>
            <p id="contentBox"></p>
            
        </div>
        
    </body>

</html>

