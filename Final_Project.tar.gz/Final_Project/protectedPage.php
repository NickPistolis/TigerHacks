<?php
	
	//$username = empty($_COOKIE['username']) ? '' : $_COOKIE['username'];

if(!session_start()){
    header("Location: error.php");
    exit;
}

$loggedIn= empty($_SESSION['loggedIn']) ? false : $_SESSION['loggedIn'];
//print $_SESSION['loggedIn'];
	
	
	if (!$loggedIn) {
		header("Location: login.php");
    exit;
	}
?>
<!DOCTYPE html>
<!-- This document was created by Professor Wergeles for CS2830 at the University of Missouri -->
<html>
<head>
	<title>Protected Page</title>
    <link href="app.css" rel="stylesheet" type="text/css">
    <link href="../jquery-ui-1.11.4.custom/jquery-ui.min.css" rel="stylesheet" type="text/css">
    <script src="../jquery-ui-1.11.4.custom/external/jquery/jquery.js"></script>
    <script src="../jquery-ui-1.11.4.custom/jquery-ui.min.js"></script>
    <script
  src="https://code.jquery.com/jquery-3.1.1.js"
  integrity="sha256-16cdPddA6VdVInumRGo6IbivbERE8p7CQR3HzTBuELA="
  crossorigin="anonymous"></script>

    <style>
        #testStyle {
            margin: auto;
            font-family: 'Permanent Marker', 'Arial';
            background: white;
            margin-top: 10%;
            margin-bottom: 10%;
            width: 50%;
            height: 600px;
            text-align: center;
            border-radius: 25px;
        }

        body {
            background-image: url("Flag_of_Germany.png");
            background-size: 100%;
        }
        #content {
            
        }
    </style>
</head>
<body onload="pageLoaded()">
    
    
    <div id="testStyle">
        <br>
                        <?php
                set_include_path('templates');
                require_once("Template.php");
                require_once("MenuComponent.php");

                // Set Page Title
                $title = 'Home';
                // CSS
                $css = array();
                // HTML
                $html = array();


                // Build Menu
                $menuResult = buildMenu();
                $css[] = $menuResult['cssFile'];
                $html[] = $menuResult['html'];

                // Build Content
                $html[] = buildContent();
                $css[] = buildCSS();

                // Build Page
                $page = new Template();

                $page->title = $title;
                $page->css = $css;
                $page->html = $html;

                print $page->build('page.tmpl');



                function buildMenu() {
                    $menuItems = array();
                    $menuItems[] = array('label' => 'Home', 'link' => 'index_old.php');
                    $menuItems[] = array('label' => 'Login', 'link' => 'login.php');
                    $menuItems[] = array('label' => 'Register', 'link' => 'register.php');
                    $menuItems[] = array('label' => 'Meeting Dates', 'link' => 'meeting_dates.php');
                    $menuItems[] = array('label' => 'Videos', 'link' => 'videos.php');

                    //Need to create a variable called $currentPage
                    $currentPage = "Secret Page"; //After adding this line, it will have Home selected as the page.

                    $menu = new MenuComponent($menuItems, $currentPage);
                    return $menu->generate();
                }

                function buildContent() {
                    $content = new Template();
                    $content->myVariable = 'Mr. Wergeles';
                    //return $content->build('meeting_dates.tmpl'); //Change to a different template later.
                }
                function buildCSS() {
                    $content = new Template();
                    return $content->build('meeting_dates.tmpl');
                }

            ?>
            <h1 id="content"><b></b></h1>
            <script>
                function pageLoaded() {
                    //Create div element.
                    userInfo = document.getElementById("content");
                    //Get user id
                    userInfo.append("Welcome to the German Club admin page, " + "<?php echo $_SESSION['loggedIn']; ?>" + "!");
                    
                }
            </script>
    </div>
</body>
</html>
