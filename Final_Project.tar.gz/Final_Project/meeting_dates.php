<!DOCTYPE html>

<!-- This document was created on 26 April 2017 by Andrew Krall, 16190080-->
<!-- Purpose: CS2830 Final Project -->

<html>
    
    <head>
        
        <!-- Bootstrap Links -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css"><!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css"><!-- Optional theme -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script><!-- Latest compiled and minified JavaScript -->
        
        <title>Login</title> 
        <meta charset="utf-8"> 
        
        <script
  src="https://code.jquery.com/jquery-3.1.1.js"
  integrity="sha256-16cdPddA6VdVInumRGo6IbivbERE8p7CQR3HzTBuELA="
  crossorigin="anonymous"></script>
        
        <style>
            .testStyle {
                margin: auto;
                font-family: 'Permanent Marker', 'Arial';
                background: white;
                margin-top: 10%;
                margin-bottom: 10%;
                width: 50%;
                height: 600px;
                text-align: center;
                border-radius: 25px;
            }
            
            body {
                background-image: url("Flag_of_Germany.png");
                background-size: 100%;
            }
            
            /* Creates the border around the result. */
            #resultPane {
                width: 400px;
                height: 400px;
                border: 2px solid black;
                /* Centers the result pane on the page. */
                margin-top: 8%;
                margin-left: auto;
                margin-right: auto;
            }
        </style>
        
        <script>
            /*
            function setFallDates() {
                //var htmlTextareaObject = document.getElementById("htmlTextarea");
                //var cssTextareaObject = document.getElementById("cssTextarea");
                var htmlCode = 
                var resultPaneObject = document.getElementById("resultPane");
                var tempAreaObject = document.getElementById("headID");
                console.dir(htmlTextareaObject);

                console.log(htmlTextareaObject.value);
                resultPaneObject.innerHTML = htmlTextareaObject.value;
                console.log(cssTextareaObject.value);
                tempAreaObject.append(cssTextareaObject.value);
                tempAreaObject.value = "1";

            }
            */
            
            function setFallDates() {
                $("#resultPane").html("Loading...");
                var numOfEvents = 0;
                $.getJSON("http://ec2-54-69-23-193.us-west-2.compute.amazonaws.com/Final_Project/dates/fallDates.json", function(meetingInfo) {
                    $("#resultPane").empty();
                    //Put loop here for challenge #9, for loop through each of the JSON arrays, $.each()
                    $.each(meetingInfo, function(key, value) {
                        numOfEvents++;
                        $("#resultPane").append( "<b>Event " + numOfEvents + "</b><br>" + "Date: " + value.date + "<br>" + " Time:  " + value.time + "<br>" + value.event + "<br>" + value.location + "<br>" );
                    });
                });
            }
            
            function setSpringDates() {
                $("#resultPane").html("Loading...");
                var numOfEvents = 0;
                $.getJSON("http://ec2-54-69-23-193.us-west-2.compute.amazonaws.com/Final_Project/dates/springDates.json", function(meetingInfo) {
                    $("#resultPane").empty();
                    //Put loop here for challenge #9, for loop through each of the JSON arrays, $.each()
                    $.each(meetingInfo, function(key, value) {
                        numOfEvents++;
                        $("#resultPane").append( "<b>Event " + numOfEvents + "</b><br>" + "Date: " + value.date + "<br>" + " Time:  " + value.time + "<br>" + value.event + "<br>" + value.location + "<br>" );
                    });
                });
            }
        
        </script>
        
    </head>
    
    <body>
        
        <div class="testStyle">
            <br>
            <?php
                set_include_path('templates');
                require_once("Template.php");
                require_once("MenuComponent.php");

                // Set Page Title
                $title = 'Home';
                // CSS
                $css = array();
                // HTML
                $html = array();


                // Build Menu
                $menuResult = buildMenu();
                $css[] = $menuResult['cssFile'];
                $html[] = $menuResult['html'];

                // Build Content
                $html[] = buildContent();
                $css[] = buildCSS();

                // Build Page
                $page = new Template();

                $page->title = $title;
                $page->css = $css;
                $page->html = $html;

                print $page->build('page.tmpl');



                function buildMenu() {
                    $menuItems = array();
                    $menuItems[] = array('label' => 'Home', 'link' => 'index_old.php');
                    $menuItems[] = array('label' => 'Login', 'link' => 'login.php');
                    $menuItems[] = array('label' => 'Register', 'link' => 'register.php');
                    $menuItems[] = array('label' => 'Meeting Dates', 'link' => 'meeting_dates.php');
                    $menuItems[] = array('label' => 'Videos', 'link' => 'videos.php');

                    //Need to create a variable called $currentPage
                    $currentPage = "Meeting Dates"; //After adding this line, it will have Home selected as the page.

                    $menu = new MenuComponent($menuItems, $currentPage);
                    return $menu->generate();
                }

                function buildContent() {
                    $content = new Template();
                    $content->myVariable = 'Mr. Wergeles';
                    //return $content->build('meeting_dates.tmpl'); //Change to a different template later.
                }
                function buildCSS() {
                    $content = new Template();
                    return $content->build('meeting_dates.tmpl');
                }

            ?>
            
            <div id="resultPane">
            </div>
            
            <button type="button" onclick="setFallDates()">Fall 2016 Semester</button>
            <button type="button" onclick="setSpringDates()">Spring 2017 Semester</button>
                
            <p id="contentBox"></p>
            
            
            
        </div>
        
    </body>

</html>

