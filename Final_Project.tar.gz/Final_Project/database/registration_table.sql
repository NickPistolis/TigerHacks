DROP TABLE IF EXISTS `Registration`;

CREATE TABLE Registration(
	`name` varchar(150),
	`grade` varchar(20),
	`email` varchar(255),
	PRIMARY KEY(`email`)
);
