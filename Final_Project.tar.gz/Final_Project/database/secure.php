<?php
	DEFINE("HOST", "localhost");
	DEFINE("DBNAME", "final_project");
	DEFINE("USERNAME", "ec2-user");
	DEFINE("PASSWORD", "temp1234");
?>

